<nav class="panel-menu" id="mobile-menu">
    <ul>
	</ul>
    <div class="mm-navbtn-names">
        <div class="mm-closebtn"><?php esc_html_e('Close','caleader');?></div>
        <div class="mm-backbtn"><?php esc_html_e('Back','caleader');?></div>
    </div>
</nav>