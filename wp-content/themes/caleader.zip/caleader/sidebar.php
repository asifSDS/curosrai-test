<?php
if(is_active_sidebar('blog_sideber')){
    dynamic_sidebar('blog_sideber');
}