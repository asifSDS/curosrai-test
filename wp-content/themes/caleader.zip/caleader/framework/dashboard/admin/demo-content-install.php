<div id="getting-started" class="about-wrap">
	<div class="feature-section two-col">
		<?php echo esc_html__( 'You need to Install and Active Demo Importer Plugin For Demo Import.', 'caleader' ); ?>
	</div>
</div>
