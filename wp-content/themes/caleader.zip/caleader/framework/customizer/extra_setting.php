<?php
$fields[] = array(
	'type'     => 'text',
	'settings' => 'servide_slug',
	'label'    => esc_html__( 'Service post type slug', 'caleader' ),
	'section'  => 'extra_setting',
	'default'  => 'carleader-services',
	'priority' => 10,
);