<?php
$fields[] =   array(
	'type'     => 'textarea',
	'settings' => 'modal_shortcode_modal_test_drive_content',
	'label'    => esc_html__( 'Modal for Test Drive', 'caleader' ),
	'section'  => 'modal_shortcode',
	'default'  => '',
	'priority' => 10,
) ;
$fields[] =   array(
	'type'     => 'textarea',
	'settings' => 'modal_shortcode_modal_add_item_content',
	'label'    => esc_html__( 'Modal for Add Item', 'caleader' ),
	'section'  => 'modal_shortcode',
	'default'  => '',
	'priority' => 10,
) ;